#ifndef GLOBALMASTERCOLVARS_H
#define GLOBALMASTERCOLVARS_H


#include "colvarmodule.h"
#include "colvarproxy.h"
#include "colvarproxy_namd.h"

typedef colvarproxy_namd GlobalMasterColvars;


#endif
